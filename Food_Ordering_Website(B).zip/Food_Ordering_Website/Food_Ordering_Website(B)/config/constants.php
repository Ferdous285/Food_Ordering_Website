<?php

    session_start();

    // Create constants to store non reapeating values
    define('SITEURL', 'http://localhost/Food_Ordering_Website/Food_Ordering_Website(B)/');
    define('LOCALHOST', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'food-order');

    // Making Database connection
    $conn = mysqli_connect(LOCALHOST, DB_USERNAME,  DB_PASSWORD) or die(mysqli_error());  // Database connection
    $db_select = mysqli_select_db($conn, DB_NAME) or die(mysqli_error()); // Selecting Database

?>