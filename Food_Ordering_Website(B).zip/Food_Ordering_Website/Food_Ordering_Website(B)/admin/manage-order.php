<?php include('partials/menu.php'); ?>

<!-- Main sention start -->

<div class="main-content">
    <div class="wrapper">
        <h1>Manage Order</h1>
    </div>
</div>

<!-- Main section ends -->

<?php include('partials/footer.php'); ?>
