<?php include('partials/menu.php'); ?>


        <!-- Main Content Starts -->
        <div class="main-content">  
            <div class="wrapper">
                <h1>DASHBOARD</h1>
                    
                <?php
                    if(isset($_SESSION['login']))
                    {
                        echo $_SESSION['login'];
                        unset($_SESSION['login']);
                    }
                ?>
                <div class="col-4 text-center">
                    <h1>1</h1>
                    <br>
                    Catagories
                </div>

                <div class="col-4 text-center">
                    <h1>2</h1>
                    <br>
                    Catagories
                </div>

                <div class="col-4 text-center">
                    <h1>3</h1>
                    <br>
                    Catagories
                </div>

                <div class="col-4 text-center">
                    <h1>4</h1>
                    <br>
                    Catagories
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- Main Content Ends -->


<?php include('partials/footer.php'); ?>